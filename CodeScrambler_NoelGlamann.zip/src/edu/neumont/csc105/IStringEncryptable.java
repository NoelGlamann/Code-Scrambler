package edu.neumont.csc105;

public interface IStringEncryptable {
    String getName();
    String encrypt(String s);
    String decrypt(String s);
}
